<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @NorthSms_bot",
	'parse_mode' => 'html'
]);